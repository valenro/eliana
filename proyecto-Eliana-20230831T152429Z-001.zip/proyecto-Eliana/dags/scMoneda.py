import requests
import json
import math
from datetime import datetime, timedelta
import pandas as pd
from sqlalchemy import create_engine
from decouple import Config
import os
from dotenv import load_dotenv

load_dotenv()

REDSHIFT_USERNAME = os.getenv('REDSHIFT_USERNAME')
REDSHIFT_PASSWORD = os.getenv('REDSHIFT_PASSWORD')

def truncate(number, digits) -> float:
    stepper = 10.0 ** digits
    return math.trunc(stepper * number) / stepper

def get_data(crypto):
    url = f"https://api.coingecko.com/api/v3/coins/{crypto}/market_chart/range"
    start_date = datetime(2023, 1, 1)
    end_date = datetime(2023, 6, 30)
    params = {
        'vs_currency': 'usd',
        'from': start_date.timestamp(),
        'to': end_date.timestamp()
    }
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()
    return data

def get_coin_details(crypto):
    url = f"https://api.coingecko.com/api/v3/coins/{crypto}"
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()
    return data

# Conexión a Redshift usando SQLAlchemy con el dialecto específico de Redshift
DATABASE_URL = 'redshift+psycopg2://{REDSHIFT_USERNAME}:{REDSHIFT_PASSWORD}@data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com:5439/data-engineer-database'
engine = create_engine(DATABASE_URL)

cryptos = ['bitcoin', 'ethereum', 'tether', 'ripple', 'binancecoin', 'usd-coin', 'cardano', 'dogecoin', 'solana', 'tron', 'litecoin', 'polkadot']

# Crear un DataFrame vacío
df = pd.DataFrame(columns=['crypto', 'fecha', 'precio_apertura', 'precio_cierre', 'market_cap', 'volumen_total', 'market_cap_rank', 'last_updated', 'circulating_supply', 'total_supply'])

for crypto in cryptos:
    try:
        data = get_data(crypto)
        coin_details = get_coin_details(crypto)
        if 'prices' in data:
            for i in range(len(data['prices'])):
                fecha = datetime.fromtimestamp(data['prices'][i][0]/1000).strftime('%Y-%m-%d')
                precio_apertura = truncate(data['prices'][i][1], 2) if i == 0 or fecha != datetime.fromtimestamp(data['prices'][i-1][0]/1000).strftime('%Y-%m-%d') else None
                precio_cierre = truncate(data['prices'][i][1], 2)
                market_cap = truncate(data['market_caps'][i][1], 2)
                volumen_total = truncate(data['total_volumes'][i][1], 2)
                market_cap_rank = coin_details['market_data'].get('market_cap_rank', None)
                last_updated = coin_details['market_data'].get('last_updated', None)
                circulating_supply = coin_details['market_data'].get('circulating_supply', None)
                total_supply = coin_details['market_data'].get('total_supply', None)

                # Agregar la nueva fila directamente al DataFrame existente con loc
                df.loc[len(df)] = [crypto, fecha, precio_apertura, precio_cierre, market_cap, volumen_total, market_cap_rank, last_updated, circulating_supply, total_supply]
        else:
            print(f"No se encontraron precios para {crypto}")
    except requests.HTTPError as e:
        print(f"Error al obtener datos para {crypto}: {e}")

# Cargar el DataFrame completo en Redshift
df.to_sql('crypto_market_data', engine, if_exists='append', index=False)