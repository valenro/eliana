Entrega 3 Dataengineering
+++++++++++++++++++++++++++++++++++++++++++++++++++++++

Requerimientos
-------------------------------------------------------
tener Docker desktop instalado

Descripción
-------------------------------------------------------
Nombre DAG: DAG_scMoneda.py
este dag contiene las tareas necesarias para la ETL de información proveniente de la API coingecko.
Más detalladamente.
1. Extrae datos de criptomonedas desde el 1/1/2023 hasta el 30/06/2023
2. Crea una tabla en una base de datos de Amazon Redshift e inserta los datos referentes a cada dia.

Credenciales de Redshift
-------------------------------------------------------
El archivo contrasenia.env tiene las credenciales de redshift


