from datetime import datetime, timedelta
import requests
import math
import pandas as pd
from sqlalchemy import create_engine
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from scMoneda import get_data, get_coin_details, process_data, load_to_redshift

default_args = {
    'owner': 'Eliana',
    'retries': 5,
    'retry_delay': timedelta(minutes=5)
}



with DAG(default_args=default_args,
        dag_id='dag_con_conexion_redshift',
        description='DAG usando Redshift Operator Eliana Costa',
        start_date=datetime(2023, 8, 15),
        schedule_interval='0 0 * * *',
        catchup=False) as dag:


    t1 = PythonOperator(
        task_id='get_data_task',
        python_callable=get_data,
        dag=dag
    )

    t2 = PythonOperator(
        task_id='get_coin_details_task',
        python_callable=get_coin_details,
        dag=dag
    )

    t3 = PythonOperator(
        task_id='process_data_task',
        python_callable=process_data,
        dag=dag
    )

    t4 = PythonOperator(
        task_id='load_to_redshift_task',
        python_callable=load_to_redshift,
        dag=dag
    )

    t1 >> t2 >> t3 >> t4